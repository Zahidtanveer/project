﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DisplayDataonTable.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

      public ActionResult displayData(int accountNumber)
        {
            DataSet dsQ1 = SqlQuery(string.Format("select * from displayDate where accountnumber={0}", accountNumber));

            if (dsQ1.Tables[0].Rows.Count > 0)
                ViewBag.DsData1 = dsQ1;
            else
                ViewBag.DsData1 = null;


            return View();
        }

        DataSet SqlQuery(string query)
        {
            DataSet ds = new DataSet();
            //Get Connection String
            string cnx = ConfigurationManager.ConnectionStrings["cnx"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cnx))
            {
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }

            return ds;
        }


    }
}